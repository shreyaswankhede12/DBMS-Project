from django.contrib import admin
from QandA.models import users
# Register your models here.
admin.site.register(users)